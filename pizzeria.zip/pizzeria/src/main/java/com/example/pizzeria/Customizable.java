package com.example.pizzeria;

public interface Customizable {
    boolean add(Object obj);
    boolean remove(Object obj);
}
