package com.example.pizzeria;

public class main22 {
    public static void main(String args[]){
        BBQChicken A = new BBQChicken(Crust.brooklyn,Size.small);
        System.out.println(A.getToppings());
        System.out.println(A.getPrice());
        Deluxe A2 = new Deluxe(Crust.brooklyn,Size.large);
        System.out.println(A2.getCrust());
        System.out.println(A2.getPrice());



    }
}
