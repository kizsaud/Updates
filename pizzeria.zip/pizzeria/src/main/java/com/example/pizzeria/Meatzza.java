package com.example.pizzeria;

import java.util.ArrayList;

public class Meatzza extends Pizza{
    private Crust crust;
    private Size size;
    private ArrayList<Topping> toppings;
    private ArrayList<Topping> toppings2;
    private double price;

    public Crust getCrust() {
        return crust;
    }

    public Size getSize() {
        return size;
    }

    public ArrayList<Topping> getToppings2() {
        return toppings2;
    }

    public double getPrice() {
        return price;
    }

    public Meatzza(Crust crust, Size size) {
        super(crust,size);
        this.crust=crust;
        this.size=size;
        this.toppings=setToppings();
        this.price=price();




    }
    private ArrayList<Topping> setToppings(){
        ArrayList<Topping> toppings = new ArrayList<Topping>();
        toppings.add(Topping.Sausage);
        toppings.add(Topping.pepperoni);
        toppings.add(Topping.beef);
        toppings.add(Topping.ham);

        return toppings;
    }

    public ArrayList<Topping> getToppings() {
        return toppings;
    }

    @Override
    public boolean add(Object obj) {
        return false;
    }

    @Override
    public boolean remove(Object obj) {
        return false;
    }

    @Override
    public double price() {
        double price=0;
        if(this.size.equals(Size.small)){
            price= 15.99;
        }
        if(this.size.equals(Size.large)){
            price=19.99;
        }
        if(this.size.equals(Size.medium)){
            price=17.99;
        }
        return price;
    }








}
