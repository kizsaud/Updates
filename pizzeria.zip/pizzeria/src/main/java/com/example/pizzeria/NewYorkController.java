package com.example.pizzeria;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class NewYorkController implements Initializable {


    ObservableList<String> pizza_style = FXCollections.observableArrayList("Build Your Own", "BBQChicken", "Meatzza","Deluxe");
    ObservableList<String> topping_options = FXCollections.observableArrayList("Sausage", "pepperoni",
            "BBQ_chicken", "green_pepper","beef", "ham", "pineapple","provolone","cheadder", "red_pepper", "onion,mushrooms","spinach", "feta_cheese");
    @FXML private RadioButton Small;

    @FXML
    private ChoiceBox<String> pizzaDropDown;
    @FXML private ListView<String> toppingbox;
    @FXML private TextField crust;
    @FXML private Button settype;
    @FXML private Button addTopping;
    @FXML private Button removeTopping;
    @FXML private TextField price2;
    @FXML private RadioButton small;
    @FXML private RadioButton Large;
    @FXML private RadioButton Medium;
    @FXML private TextArea textArea;

    @FXML private Button sonOf;
    @FXML private ListView<String> selectedToppings;
    private ArrayList <Topping> selectedToppings2=new ArrayList<>();
    private int numberOfToppings =0;
    double price;
    double iter=0;
    @FXML private ImageView B;
    public void pizzaSelection() {
        // pizzaOrder = new PizzaOrder();

        try {
            if (pizzaDropDown.getValue().equals("Deluxe")) {
                selectedToppings.getItems().clear();

                //  System.out.println("Already dsa");

                setDeluxeToppings();
                enable_disable_addAndRemove_options(true);

            }
            else if(pizzaDropDown.getValue().equals("BBQChicken")){
                selectedToppings.getItems().clear();
                setBBQChicken();
                enable_disable_addAndRemove_options(true);
            }
            else if(pizzaDropDown.getValue().equals("Meatzza")){
                selectedToppings.getItems().clear();
                setMeatzza();
                enable_disable_addAndRemove_options(true);
            }
            else if(pizzaDropDown.getValue().equals("Build Your Own")){
                selectedToppings.getItems().clear();
                enable_disable_addAndRemove_options(false);

                toppingbox.setItems(topping_options);
                toppingbox.getSelectionModel().select(0);

            }
            else {
                selectedToppings.getItems().clear();

                //  System.out.println("Already entered");
            }
        }catch (NullPointerException e ){
            selectedToppings.getItems().clear();


        }
    }
    public void setCustom(String topping){


    }

    public void enable_disable_addAndRemove_options(boolean value) {
        addTopping.setDisable(value);
        toppingbox.setDisable(value);
        removeTopping.setDisable(value);
    }
    public void setBBQChicken(){

        selectedToppings.getItems().add("BBQ_Chicken");
        selectedToppings.getItems().add("Green_Pepper");
        selectedToppings.getItems().add("Provolone");
        selectedToppings.getItems().add("Cheadder");




    }
    public void setMeatzza() {
        selectedToppings.getItems().add("Sausage");
        selectedToppings.getItems().add("Pepperoni");
        selectedToppings.getItems().add("beef");
        selectedToppings.getItems().add("ham");
    }
    public void setDeluxeToppings() {


        selectedToppings.getItems().add("Sausage");
        selectedToppings.getItems().add("Onion");
        selectedToppings.getItems().add("Mushroom");
        selectedToppings.getItems().add("pepperoni");



    }


    //So if the selected drag down menu has Deluxe selected or Meatzaa, or BBQChicken we need to chck for that to create the right pizza!

    public void updatePrice(){
        double storedPrice=getPrice();

        price +=1.59;
        price2.setText(String.valueOf(price));


    }
    public double getPrice(){
        return price;
    }
    @FXML
    private void remove(){
        //    selectedToppings.getSelectionModel().se
        if(selectedToppings.getItems().remove(selectedToppings.getSelectionModel().getSelectedItem())){
            price2.setText(String.valueOf(price-=1.59));
            int index = selectedToppings2.size() - 1;

            if(index>=0){
                selectedToppings2.remove(index);
            }
        }



    }







    public void add_toppings() {
        int MAX_TOPPINGS = 7;
        String selected_topping = toppingbox.getSelectionModel().getSelectedItem();
        if (selectedToppings.getItems().contains(selected_topping)) {
            System.out.println("You have already added that topping!\n");
            textArea.clear();
            textArea.setText("You have already entered that topping!!");

        } else if (!(numberOfToppings < MAX_TOPPINGS)) {
            System.out.println("Sorry, you cannot add more than 7 toppings!\n");
            textArea.clear();
            textArea.setText("Sorry, you cannot add more than 7 toppings");
        } else {
            if (Medium.isSelected() || Large.isSelected() || small.isSelected()) {

                selectedToppings.getItems().add(selected_topping);
                if (selected_topping.equalsIgnoreCase("Sausage")) {
                    selectedToppings2.add(Topping.Sausage);
                }
                if (selected_topping.equalsIgnoreCase("pepperoni")) {
                    selectedToppings2.add(Topping.pepperoni);
                }
                if (selected_topping.equalsIgnoreCase("BBQ_chicken")) {
                    selectedToppings2.add(Topping.BBQ_chicken);
                }
                if (selected_topping.equalsIgnoreCase("green_pepper")) {
                    selectedToppings2.add(Topping.green_pepper);
                }
                if (selected_topping.equalsIgnoreCase("beef")) {
                    selectedToppings2.add(Topping.beef);
                }
                if (selected_topping.equalsIgnoreCase("ham")) {
                    selectedToppings2.add(Topping.ham);
                }
                if (selected_topping.equalsIgnoreCase("pineapple")) {
                    selectedToppings2.add(Topping.pineapple);
                }
                if (selected_topping.equalsIgnoreCase("provolone")) {
                    selectedToppings2.add(Topping.provolone);
                }
                //       cheadder, red_pepper, onion,mushrooms,spinach, feta_cheese;

                if (selected_topping.equalsIgnoreCase("cheadder")) {
                    selectedToppings2.add(Topping.cheadder);
                }
                if (selected_topping.equalsIgnoreCase("red_pepper")) {
                    selectedToppings2.add(Topping.red_pepper);
                }
                if (selected_topping.equalsIgnoreCase("onion")) {
                    selectedToppings2.add(Topping.onion);
                }
                if (selected_topping.equalsIgnoreCase("mushrooms")) {
                    selectedToppings2.add(Topping.mushrooms);
                }
                if (selected_topping.equalsIgnoreCase("spinach")) {
                    selectedToppings2.add(Topping.spinach);
                }
                if (selected_topping.equalsIgnoreCase("feta_cheese")) {
                    selectedToppings2.add(Topping.feta_cheese);
                }


                updatePrice();

                numberOfToppings++;
                iter++;
            }
            else{
                textArea.setText("Must select a size");
            }

        }
    }



    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        //  BBQChicken A = BBQChicken(Crust.valueOf(getCrust()), Size.valueOf());

        // TODO Auto-generated method stub
        //showOrder.setText("Hey There");
        toppingbox.setItems(topping_options);
        pizzaDropDown.setItems(pizza_style);
        System.out.println(pizzaDropDown.getValue());
        toppingbox.getSelectionModel().select(0);






    }


    @FXML
    private void getType(){
        price2.clear();
        if(small.isSelected()){
            small.setSelected(false);
        }
        if(Medium.isSelected()){
            Medium.setSelected(false);
        }
        if(Large.isSelected()){
            Large.setSelected(false);
        }
        if(pizzaDropDown.getValue()==null){
            B.setImage(null);
        }

        getCrust();
        pizzaDropDown.show();
        pizzaDropDown.getSelectionModel().selectedItemProperty().addListener((v,oldvalue,newValue)->getCrust());


    }

    private Crust getCrust2(){
        Crust crust2=null;
        if(crust.getText().equals("Hand tossed")){
            crust2=Crust.handtossed;

        }
        if(crust.getText().equals("Thin")){
            crust2=Crust.thin;

        }
        if(crust.getText().equals("Brooklyn")){
            crust2=Crust.brooklyn;

        }
        return crust2;



    }
    @FXML
    private String getSize(){

        int count=0;
        String returnSize="";
        if(small.getText().equals("Small")){
            returnSize="Small";

        }
        else if(small.getText().equals("Medium")){
            returnSize="Medium";


        }
        else if(Small.getText().equals("Large")){
            returnSize="Large";
        }
        return returnSize;
    }
    @FXML
    private String getSmall() {

        if (pizzaDropDown.getValue() == "Meatzza") {
            if (small.isSelected()){

                price2.clear();
                price = 15.99;
                price2.setText(String.valueOf(price));


            } else if (Large.isSelected()) {

                price2.clear();
                System.out.println("HERE!");

                price = 19.99;
                price2.setText(String.valueOf(price));


            } else if (Medium.isSelected()) {

                price2.clear();

                price = 17.99;
                price2.setText(String.valueOf(price));


            }

        }
        else if(pizzaDropDown.getValue()=="Deluxe"){
            price=0;
            if (small.isSelected()){

                price2.clear();
                price = 14.99;
                price2.setText(String.valueOf(price));


            } else if (Large.isSelected()) {

                price2.clear();
                System.out.println("HERE!");

                price = 18.99;
                price2.setText(String.valueOf(price));


            } else if (Medium.isSelected()) {

                price2.clear();

                price = 16.99;
                price2.setText(String.valueOf(price));


            }
        }
        else if(pizzaDropDown.getValue()=="BBQChicken"){
            price=0;

            if (small.isSelected()){

                price2.clear();
                price = 13.99;
                price2.setText(String.valueOf(price));


            } else if (Large.isSelected()) {

                price2.clear();
                System.out.println("HERE!");

                price = 17.99;
                price2.setText(String.valueOf(price));


            } else if (Medium.isSelected()) {

                price2.clear();

                price = 15.99;
                price2.setText(String.valueOf(price));


            }
        }
        else if(pizzaDropDown.getValue()=="Build Your Own"){
            price=0;


            if (small.isSelected()){
                selectedToppings.getItems().clear();
                numberOfToppings=0;


                price2.clear();

                price=8.99;


                price2.setText(String.valueOf(price));


            } else if (Large.isSelected()) {
                selectedToppings.getItems().clear();
                numberOfToppings=0;


                price2.clear();
                System.out.println("HERE!");

                price = 12.99;
                price2.setText(String.valueOf(price));


            } else if (Medium.isSelected()) {
                selectedToppings.getItems().clear();
                numberOfToppings=0;


                price2.clear();

                price = 10.99;
                price2.setText(String.valueOf(price));


            }
        }

        return String.valueOf(price);
    }
    private Size getSize2(){
        Size size2=null;
        if(small.isSelected()){
            size2=Size.small;

        }
        if(Medium.isSelected()){
            size2=Size.medium;
        }
        if(Large.isSelected()){
            size2=Size.large;
        }
        return size2;

    }
    @FXML
    private void createPizza() {
        String crust = getCrust();
        String style = getSize();

        if (Medium.isSelected() || small.isSelected() || Large.isSelected()) {

            if (pizzaDropDown.getValue().equals("BBQChicken")) {
                BBQChicken Pizza = new BBQChicken(getCrust2(), getSize2());

                System.out.println("SUCCESS created BBQ pizza");
                System.out.println(Pizza.getPrice());
                System.out.println(Pizza.getToppings());
                System.out.println(Pizza.getSize());


            }
            if (pizzaDropDown.getValue().equals("Meatzza")) {
                Meatzza Pizza = new Meatzza(getCrust2(), getSize2());
                System.out.println("SUCCESS created Meatzaa  pizza");
                System.out.println(Pizza.getPrice());
                System.out.println(Pizza.getToppings());
                System.out.println(Pizza.getSize());


            }
            if (pizzaDropDown.getValue().equals("Deluxe")) {
                Deluxe Pizza = new Deluxe(getCrust2(), getSize2());
                System.out.println("SUCCESS created Deluxe pizza");
                System.out.println(Pizza.getPrice());
                System.out.println(Pizza.getToppings());
                System.out.println(Pizza.getSize());


            }
            if (pizzaDropDown.getValue().equals("Build Your Own")) {


                BuildYourOwn Pizza = new BuildYourOwn(getCrust2(), getSize2(), selectedToppings2, price);
                System.out.println(Pizza.getToppings().toString());
                System.out.println(Pizza.getPrice());


            }

        }else{
            textArea.setText("Must select a size before ordering");
        }
        selectedToppings2.clear();
        numberOfToppings=0;
        resetPrice();
    }
    @FXML
    private void resetPrice(){
        price2.clear();
        price2.setText("");
    }


    //this getss the type of pizza getType
    @FXML
    private String getCrust(){
        String returnString = "";
        if(pizzaDropDown.getValue()=="BBQChicken"){
            crust.setText("Thin");
            returnString="Thin";
            B.setImage(new Image("C:\\Users\\kizsa\\IdeaProjects\\newFolder\\pizzeria\\src\\main\\java\\com\\example\\pizzeria\\test\\BBQChicken.jpeg"));

        }
        else if(pizzaDropDown.getValue()=="Deluxe"){
            crust.setText("Brooklyn");
            returnString="Brooklyn";
            B.setImage(new Image("C:\\Users\\kizsa\\IdeaProjects\\newFolder\\pizzeria\\src\\main\\java\\com\\example\\pizzeria\\test\\Deluxe.jpeg"));


        }
        else if(pizzaDropDown.getValue()=="Meatzza"){
            crust.setText("Hand tossed");
            returnString="Hand tossed";
            B.setImage(new Image("C:\\Users\\kizsa\\IdeaProjects\\newFolder\\pizzeria\\src\\main\\java\\com\\example\\pizzeria\\test\\Meatzaa.jpeg"));

        }
        else if(pizzaDropDown.getValue()=="Build Your Own"){
            crust.setText("Hand tossed");
            returnString="Hand tossed";
            B.setImage(new Image("C:\\Users\\kizsa\\IdeaProjects\\newFolder\\pizzeria\\src\\main\\java\\com\\example\\pizzeria\\test\\Buildyourownpage.jpeg"));

        }

        else{
            crust.setText("default");
            returnString="default";
        }
        pizzaSelection();

        return returnString;

    }

}
