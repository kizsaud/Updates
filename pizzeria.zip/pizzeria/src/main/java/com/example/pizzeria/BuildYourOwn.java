package com.example.pizzeria;

import java.util.ArrayList;

public class BuildYourOwn extends Pizza{
    private Size size;
    private Crust crust;
    private Topping toppings;
    private ArrayList<Topping> topping2s;
    double price=0;

    public BuildYourOwn(Crust crust, Size size, ArrayList<Topping> toppings,double price) {
        super(crust, size, toppings);
        this.topping2s=toppings;
        this.price=price;
    }
    @Override
    public boolean add(Object obj) {
        return false;
    }

    @Override
    public boolean remove(Object obj) {
        return false;
    }
    public ArrayList<Topping> getToppings(){
        return topping2s;
    }
    public double getPrice() {
        return price;
    }





    @Override
    public String toString() {
        return super.toString() + "\nPizza Price: $ " + this.price() + "\n";
    }



    @Override

    public double price() {

        return 0;
    }

}
