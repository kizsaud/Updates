package com.example.pizzeria;

import java.util.ArrayList;

public abstract class Pizza implements Customizable {
    private ArrayList<Topping> toppings;
    private Crust crust;
    private Size size;
    private String [] toppings2;

    private String crust2;
    private String size2;

    public abstract double price();
    public Pizza(Crust style, Size size, ArrayList<Topping> toppings){
        this.toppings=toppings;
        this.crust=style;
        this.size=size;
    }
    public Pizza(Crust style, Size size){
        this.toppings=toppings;
        this.crust=style;
        this.size=size;
    }
    public Pizza(String style, String size){
        this.crust2=style;
        this.size2=size;

    }
    public boolean add() {
        toppings.add(Topping.mushrooms);
        toppings.add(Topping.green_pepper);
        toppings.add(Topping.BBQ_chicken);
        toppings.add(Topping.cheadder);

        return true;
    }

}
