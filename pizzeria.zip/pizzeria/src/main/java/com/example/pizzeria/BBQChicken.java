package com.example.pizzeria;

import java.util.ArrayList;
import java.util.List;

public class BBQChicken extends Pizza{
    //This is the basic method for pre selected topppings.
    private Crust crust;
    private Size size;
    private ArrayList<Topping> toppings;
    private double price;

    public Crust getCrust() {
        return crust;
    }

    public Size getSize() {
        return size;
    }


    public ArrayList<Topping> getToppings() {
        return toppings;
    }

    public double getPrice() {
        return price;
    }

    public BBQChicken(Crust crust, Size size) {
        super(crust,size);
        this.crust=crust;
        this.size=size;
        this.toppings=setToppings();
        this.price=price();



    }
    public BBQChicken(String crust,String size){
        super(crust,size);
        if(crust.equals("Pan")){

        }

    }
    private ArrayList<Topping> setToppings(){
        ArrayList<Topping> toppings = new ArrayList<Topping>();
        toppings.add(Topping.BBQ_chicken);
        toppings.add(Topping.green_pepper);
        toppings.add(Topping.provolone);
        toppings.add(Topping.cheadder);

        return toppings;
    }


    @Override
    public boolean add(Object obj) {
        boolean trueFal=false;
      if( toppings.add((Topping) obj)){
          trueFal=true;

      }


        return trueFal;
    }

    @Override
    public boolean remove(Object obj) {
        return false;
    }

    @Override
    public double price() {
        double price=2;
        if(this.size.equals(Size.small)){
            this.price= 13.99;
        }
        else if(this.size.equals(Size.large)){
            this.price=17.99;
        }
       else if(this.size.equals(Size.medium)){
            this.price=15.99;
        }
        return this.price;
    }
}
