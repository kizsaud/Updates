package com.example.pizzeria;

public enum Crust {
    deepdish,pan,stuffed,brooklyn,thin,handtossed

}
