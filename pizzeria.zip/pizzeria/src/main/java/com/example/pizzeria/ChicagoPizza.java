package com.example.pizzeria;

public class ChicagoPizza implements PizzaFactory{
    @Override
    public Pizza createDeluxe() {
        return null;
    }

    @Override
    public Pizza createMeatzza() {
        return null;
    }

    @Override
    public Pizza createBBQChicken() {
        return null;
    }

    @Override
    public Pizza createBuildYourOwn() {
        return null;
    }
}
